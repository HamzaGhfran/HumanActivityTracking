package com.example.fragma.ui.slideshow;

import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.os.SystemClock;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.fragma.R;

public class DistanceCoverActivity extends AppCompatActivity implements SensorEventListener {

    private TextView txtDistance;
    private TextView txtSteps;
    private TextView txtAvgSpeed;
    private Button btnStartWalk;
    private Button btnStartRun;
    private Button btnStart;
    private Button btnStop;
    private EditText editText1;

    private SensorManager sensorManager;
    private Sensor stepSensor;
    private long startTime;
    private int stepsCount = 0;
    private float distanceCovered = 0;
    private float totalSpeed = 0;
    private int speedCount = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_distance_cover);

        txtDistance = findViewById(R.id.txtDistance);
        txtSteps = findViewById(R.id.txtSteps);
        txtAvgSpeed = findViewById(R.id.txtAvgSpeed);
        btnStartWalk = findViewById(R.id.btnStartWalk);
        btnStartRun = findViewById(R.id.btnStartRun);
        btnStart = findViewById(R.id.btnStart);
        btnStop = findViewById(R.id.btnStop);


        btnStartWalk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startTracking();
            }
        });

        btnStartRun.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startTracking();
            }
        });

        btnStart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startTracking();
            }
        });

        btnStop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                stopTracking();
            }
        });

        sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
        if (sensorManager != null) {
            stepSensor = sensorManager.getDefaultSensor(Sensor.TYPE_STEP_COUNTER);
        }
    }

    private void startTracking() {
        startTime = SystemClock.elapsedRealtime();
        stepsCount = 0;
        distanceCovered = 0;
        totalSpeed = 0;
        speedCount = 0;
        float strideLength = calculateStrideLength(); // Calculate the user's stride length
        distanceCovered = strideLength * stepsCount;



        txtDistance.setText(getString(R.string.distance, 0.0f));
        txtSteps.setText(getString(R.string.steps, 0));
        txtAvgSpeed.setText(getString(R.string.avg_speed, 0.0));

        if (stepSensor != null) {
            sensorManager.registerListener(this, stepSensor, SensorManager.SENSOR_DELAY_NORMAL);
        }
    }

    private void stopTracking() {
        if (stepSensor != null) {
            sensorManager.unregisterListener(this, stepSensor);
        }

        long elapsedTime = SystemClock.elapsedRealtime() - startTime;

        txtDistance.setText(getString(R.string.distance, distanceCovered));
        txtSteps.setText(getString(R.string.steps, stepsCount));

        // Calculate average speed
        float averageSpeed = totalSpeed / speedCount;
        txtAvgSpeed.setText(getString(R.string.avg_speed, averageSpeed));

        // Perform any additional calculations or actions based on the tracked data
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        if (event.sensor.getType() == Sensor.TYPE_STEP_COUNTER) {
            stepsCount = (int) event.values[0];
            txtSteps.setText(getString(R.string.steps, stepsCount));

            // Perform distance calculation based on the user's stride length
            float strideLength = calculateStrideLength(); // Calculate the user's stride length
            distanceCovered = strideLength * stepsCount;
            txtDistance.setText(getString(R.string.distance, distanceCovered));

            // Calculate speed based on the elapsed time
            long elapsedTime = SystemClock.elapsedRealtime() - startTime;

            // Ensure that elapsedTime is not zero to avoid division by zero
            if (elapsedTime > 0) {
                float speed = distanceCovered / elapsedTime; // Calculate speed in meters per millisecond
                totalSpeed += speed;
                speedCount++;
            }

            // Perform any additional actions based on the tracked data
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {
        // Handle accuracy changes if needed
    }

    private float calculateStrideLength() {
        // Retrieve user's height (in centimeters) and gender from some data source
        float userHeight = 75.0f; // Replace with your method to get user's height
        String userGender = "male"; // Replace with your method to get user's gender

        // Define average stride length values based on gender (in centimeters)
        float averageMaleStrideLength = 78.0f;
        float averageFemaleStrideLength = 70.0f;

        // Calculate stride length based on user's height and gender
        float strideLength;
        if (userGender.equalsIgnoreCase("male")) {
            strideLength = (userHeight * averageMaleStrideLength) / 170.0f;
        } else {
            strideLength = (userHeight * averageFemaleStrideLength) / 160.0f;
        }

        return strideLength;
    }




}
